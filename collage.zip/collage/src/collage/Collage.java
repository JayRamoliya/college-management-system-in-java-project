
package collage;


public class Collage {

    
    public static void main(String[] args) {
       
        Login log = new Login();
        log.show();
    }
    
}
